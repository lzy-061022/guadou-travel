// Internationalization - Translations
const translations = {
    zh: {
        // Nav
        company_name: "瓜豆旅游",
        nav_home: "首页",
        nav_packages: "旅游线路",
        nav_services: "服务保障",
        nav_about: "关于我们",
        nav_contact: "联系我们",
        register: "注册",
        login: "登录",

        // Hero
        hero_title: "探索红河，遇见云南",
        hero_subtitle: "瓜豆旅游 — 河口口岸起止，越南语导游全程服务，苗族古城温泉一站体验",
        hero_cta: "浏览旅游线路",
        hero_cta2: "免费咨询",

        // Stats
        stat_customers: "满意客户",
        stat_routes: "边境线路",
        stat_years: "年行业经验",
        stat_rating: "客户评分",

        // Destinations
        dest_title: "云南旅游目的地",
        dest_subtitle: "从红河边境到滇西北雪山，全云南等你来探索",
        dest_hekou: "河口",
        dest_hekou_desc: "中越门户，口岸起止",
        dest_pingbian: "屏边",
        dest_pingbian_desc: "苗族风情，滴水苗城",
        dest_mengzi: "蒙自",
        dest_mengzi_desc: "过桥米线，万亩石榴",
        dest_jianshui: "建水",
        dest_jianshui_desc: "千年古城，明清遗风",
        dest_mile: "弥勒",
        dest_mile_desc: "温泉康养，休闲胜地",
        dest_daweishan: "大围山",
        dest_daweishan_desc: "原始森林，动植物基因库",
        dest_kunming: "昆明",
        dest_kunming_desc: "春城花都，滇池海鸥",
        dest_dali: "大理",
        dest_dali_desc: "风花雪月，苍山洱海",
        dest_lijang: "丽江",
        dest_lijang_desc: "纳西古城，玉龙雪山",
        dest_shangrila: "香格里拉",
        dest_shangrila_desc: "人间仙境，雪域藏乡",
        dest_banna: "西双版纳",
        dest_banna_desc: "热带雨林，傣族风情",
        dest_lugu: "泸沽湖",
        dest_lugu_desc: "高原明珠，摩梭母系",

        // Packages
        packages_title: "云南旅游线路",
        packages_subtitle: "红河边境 · 大理丽江 · 香格里拉 · 西双版纳 · 全省覆盖",
        days: "天",
        nights: "晚",
        from: "起",
        per_person: "人",
        book_now: "立即预订",
        badge_short: "短线",
        badge_hot: "热门",
        badge_pricing: "收费标准",

        // Route filter tabs
        filter_all: "全部线路",
        filter_border: "红河边境",
        filter_yunnan: "全云南",
        filter_2d: "2天",
        filter_3d: "3天",
        filter_4d: "4天",
        filter_5d: "5天",
        filter_7d: "7天",

        // Route region headers
        route_header_border: "红河边境线路",
        route_header_yunnan: "全云南线路",

        // Destination categories
        dest_cat_border: "红河边境",
        dest_cat_northwest: "滇西北风光",
        dest_cat_tropical: "热带版纳",

        // Badge labels
        badge_classic: "经典",
        badge_compact: "紧凑",
        badge_full: "全线",
        badge_scenic: "风光",
        badge_popular: "人气",
        badge_tropical: "热带",
        badge_lake: "湖泊",
        badge_ultimate: "终极",

        // Route 1: 河口+屏边+蒙自 2天1晚
        r1_title: "河口+屏边+蒙自 2天1晚",
        r1_desc: "苗族风情+蒙自石榴人文短途游。游览4A滴水苗城牧羊河湿地公园、红河州行政中心、新安所万亩石榴园、诸子楼。",
        r1_d1: "河口→屏边（90km/1.5h）滴水苗城·牧羊河湿地",
        r1_d2: "屏边→蒙自→河口 石榴园·诸子楼·出境",

        // Route 2: 河口+建水+蒙自 2天1晚
        r2_title: "河口+建水+蒙自 2天1晚",
        r2_desc: "建水古城精华短线。朝阳楼、朱家花园、紫陶街、蒙自石榴园，不含屏边段。",
        r2_d1: "河口→建水（朝阳楼·朱家花园·紫陶街）",
        r2_d2: "建水→蒙自（石榴园·诸子楼）→河口",

        // Route 3: 河口+屏边+建水+蒙自 2天1晚
        r3_title: "河口+屏边+建水+蒙自 2天1晚",
        r3_desc: "苗城+古城紧凑组合。滴水苗城、建水朝阳楼、朱家花园、蒙自石榴园，不含大围山。",
        r3_d1: "河口→屏边（滴水苗城）→建水",
        r3_d2: "建水（朝阳楼·朱家花园）→蒙自→河口",

        // Route 4: 河口+屏边+建水+蒙自 3天2晚
        r4_title: "河口+屏边+建水+蒙自 3天2晚",
        r4_desc: "苗寨+建水古城精华版。含大围山原始森林、滴水苗城、建水朝阳楼、朱家花园、紫陶街、蒙自过桥米线。",
        r4_d1: "河口→屏边（大围山原始森林·滴水苗城）",
        r4_d2: "屏边→蒙自→建水（过桥米线·朝阳楼·朱家花园）",
        r4_d3: "建水（紫陶街·烤豆腐）→蒙自→河口",

        // Route 5: 河口+建水+弥勒+蒙自 3天2晚
        r5_title: "河口+建水+弥勒+蒙自 3天2晚",
        r5_desc: "古城+温泉休闲版。不含屏边，直达建水朝阳楼、朱家花园，弥勒温泉康养，蒙自石榴园。",
        r5_d1: "河口→建水（朝阳楼·朱家花园·紫陶街）",
        r5_d2: "建水→弥勒（温泉康养·城市观光）",
        r5_d3: "弥勒→蒙自（石榴园·诸子楼）→河口",

        // Route 6: 4天3晚
        r6_title: "河口+屏边+蒙自+建水+弥勒 4天3晚",
        r6_desc: "全线深度游！苗寨+古城+温泉全覆盖。大围山原始森林、滴水苗城、建水古城、朱家花园、弥勒温泉康养，自然人文休闲一站齐。",
        r6_d1: "河口→屏边（大围山原始森林·滴水苗城）",
        r6_d2: "屏边→蒙自→建水（过桥米线·朝阳楼·朱家花园·紫陶街）",
        r6_d3: "建水→弥勒（190km）温泉康养·城市观光",
        r6_d4: "弥勒→蒙自（石榴园·诸子楼）→河口出境",

        // Route 7: 昆明+大理 3天2晚
        r7_title: "昆明+大理 3天2晚",
        r7_desc: "春城昆明+风花雪月大理。游览滇池、大理古城、洱海游船、崇圣寺三塔、双廊古镇。",
        r7_d1: "昆明（滇池·海埂大坝·金马碧鸡坊）",
        r7_d2: "昆明→大理（大理古城·崇圣寺三塔·洱海游船）",
        r7_d3: "大理（双廊古镇·南诏风情岛）→昆明",

        // Route 8: 昆明+大理+丽江 4天3晚
        r8_title: "昆明+大理+丽江 4天3晚",
        r8_desc: "云南经典三城连线。滇池、大理古城、洱海、丽江古城、玉龙雪山、蓝月谷，一次领略云南精华。",
        r8_d1: "昆明（滇池·金马碧鸡坊）",
        r8_d2: "昆明→大理（大理古城·崇圣寺三塔·洱海游船）",
        r8_d3: "大理→丽江（丽江古城·四方街·木府）",
        r8_d4: "丽江（玉龙雪山·蓝月谷）→昆明",

        // Route 9: 昆明+大理+丽江+香格里拉 5天4晚
        r9_title: "昆明+大理+丽江+香格里拉 5天4晚",
        r9_desc: "滇西北黄金线路！春城、风花雪月、雪山古城、人间仙境全覆盖。虎跳峡、普达措、松赞林寺一次打卡。",
        r9_d1: "昆明（滇池·金马碧鸡坊）",
        r9_d2: "昆明→大理（大理古城·崇圣寺三塔·洱海游船）",
        r9_d3: "大理→丽江（丽江古城·四方街·木府）",
        r9_d4: "丽江→虎跳峡→香格里拉（独克宗古城·松赞林寺）",
        r9_d5: "香格里拉（普达措国家公园）→丽江→昆明",

        // Route 10: 昆明+西双版纳 3天2晚
        r10_title: "昆明+西双版纳 3天2晚",
        r10_desc: "热带雨林+傣族风情之旅。中科院热带植物园、野象谷、告庄星光夜市、傣族园、曼听公园。",
        r10_d1: "昆明飞版纳→中科院热带植物园→告庄星光夜市",
        r10_d2: "野象谷→傣族园·泼水活动→曼听公园",
        r10_d3: "版纳（勐泐大佛寺）→飞昆明",

        // Route 11: 昆明+大理+丽江+泸沽湖 5天4晚
        r11_title: "昆明+大理+丽江+泸沽湖 5天4晚",
        r11_desc: "高原明珠线路！洱海+泸沽湖双湖之旅。大理古城、丽江古城、摩梭走婚桥、里格半岛，湖光山色尽收眼底。",
        r11_d1: "昆明（滇池·金马碧鸡坊）",
        r11_d2: "昆明→大理（大理古城·崇圣寺三塔·洱海游船）",
        r11_d3: "大理→丽江（丽江古城·四方街·木府）",
        r11_d4: "丽江→泸沽湖（里格半岛·走婚桥·摩梭篝火晚会）",
        r11_d5: "泸沽湖（划猪槽船·里务比岛）→丽江→昆明",

        // Route 12: 全云南7天6晚
        r12_title: "全云南终极环线 7天6晚",
        r12_desc: "一次走遍云南！昆明+大理+丽江+香格里拉+西双版纳，雪山、古城、雨林、湖泊全体验，不留遗憾的云南之旅。",
        r12_d1: "昆明（滇池·金马碧鸡坊·翠湖公园）",
        r12_d2: "昆明→大理（大理古城·崇圣寺三塔·洱海游船）",
        r12_d3: "大理→丽江（丽江古城·四方街·木府）",
        r12_d4: "丽江→虎跳峡→香格里拉（松赞林寺·独克宗古城）",
        r12_d5: "香格里拉（普达措）→飞西双版纳（星光夜市）",
        r12_d6: "版纳（野象谷·傣族园·曼听公园）",
        r12_d7: "版纳（热带植物园·勐泐大佛寺）→飞昆明",

        // Landmark names
        landmarks_label: "著名景点",
        lm_miaocity: "滴水苗城",
        lm_muyang: "牧羊河湿地",
        lm_pomegranate: "万亩石榴园",
        lm_zhuzi: "诸子楼",
        lm_chaoyang: "朝阳楼",
        lm_zhugarden: "朱家花园",
        lm_purplepottery: "紫陶街",
        lm_jianshui: "建水古城",
        lm_daweishan: "大围山原始森林",
        lm_bridgenoodles: "蒙自过桥米线",
        lm_milespring: "弥勒温泉",
        lm_dianchi: "滇池",
        lm_dalitown: "大理古城",
        lm_threepagodas: "崇圣寺三塔",
        lm_erhai: "洱海",
        lm_lijtown: "丽江古城",
        lm_jadedragon: "玉龙雪山",
        lm_bluemoon: "蓝月谷",
        lm_tigerleap: "虎跳峡",
        lm_songzanlin: "松赞林寺",
        lm_botanical: "热带植物园",
        lm_elephant: "野象谷",
        lm_starlight: "星光夜市",
        lm_manting: "曼听公园",
        lm_lugu: "泸沽湖",
        lm_marriage: "走婚桥",

        // Meal includes
        inc_1b2m: "1早2正餐",
        inc_2b4m: "2早4正餐",
        inc_3b6m: "3早6正餐",
        inc_4b8m: "4早8正餐",
        inc_6b12m: "6早12正餐",

        // Price detail
        single_room: "单房差",
        tip_label: "小费",
        pricing_title: "儿童收费及费用说明",

        // Child pricing details
        inc_70: "含车位·正餐·首道门票",
        inc_30: "含车位·正餐·部分优惠门票",
        inc_10: "仅含车位·门票现场自理",

        // Fee includes/excludes
        fee_incl_title: "费用包含",
        fee_incl1: "交通：全程空调大巴，每人独立正座",
        fee_incl2: "住宿：准四星酒店标间，2人一间",
        fee_incl3: "餐饮：早正餐按行程标注，弃餐不退",
        fee_incl4: "门票：首道大门票，1.2m以上儿童同成人",
        fee_incl5: "导服：越南语导游全程服务",
        fee_incl6: "保险：云南安全组合险+出境意外险",
        fee_excl_title: "费用不含",
        fee_excl1: "个人消费：酒水零食、自选娱乐",
        fee_excl2: "健康证：口岸出入境检验检疫健康证",
        fee_excl3: "大围山门票及景区电瓶车",
        fee_excl4: "丝绸店自愿购物消费",
        fee_excl5: "行程外新增景点及特色体验",

        // Terms section
        terms_title: "出行须知",
        terms_subtitle: "参团前请仔细阅读以下条款",
        term1_title: "证件要求",
        term1_desc: "需提前办理中越边境旅游通行证，游客名单提前提交旅行社备案。老年证、军官证、学生证等境外不享受门票减免。",
        term2_title: "离团规定",
        term2_desc: "全程禁止私自离团，需签订相关协议。私自离团不退任何团费。",
        term3_title: "退费规则",
        term3_desc: "自愿弃餐、弃住一律不退费。不可抗力未产生食宿门票据实退还，额外车费住宿游客自行承担。",
        term4_title: "不可抗力",
        term4_desc: "自然灾害、交通管制、政策变动等，旅行社可调整行程，未消费项目据实退款。",
        term5_title: "投诉规则",
        term5_desc: "仅以导游现场意见单为有效凭证，返程后无凭证投诉不予受理。",
        term6_title: "行程调整",
        term6_desc: "不删减景点前提下，征得游客书面同意可调整游览顺序。",

        // Package 1: 2天1晚
        pkg1_title: "河口+屏边+蒙自 2天1晚",
        pkg1_desc: "苗族风情+蒙自石榴人文短途游。游览4A滴水苗城湿地公园、红河州行政中心、新安所万亩石榴园、诸子楼。",
        pkg1_d1: "河口→屏边（滴水苗城·牧羊河湿地）",
        pkg1_d2: "屏边→蒙自（石榴园·诸子楼）→河口",
        pkg1_inc1: "河口口岸接送",

        // Package 2: 3天2晚
        pkg2_title: "河口+屏边+蒙自+建水 3天2晚",
        pkg2_desc: "苗寨+建水古城精华版。含大围山原始森林、滴水苗城、建水朝阳楼、朱家花园、紫陶街，蒙自过桥米线。",
        pkg2_d1: "河口→屏边（大围山·滴水苗城）",
        pkg2_d2: "屏边→蒙自→建水（朝阳楼·朱家花园）",
        pkg2_d3: "建水→蒙自（石榴园）→河口",

        // Package 3: 4天3晚
        pkg3_title: "河口+屏边+蒙自+建水+弥勒 4天3晚",
        pkg3_desc: "全线深度游！苗寨+古城+温泉全覆盖。大围山原始森林、滴水苗城、建水古城、朱家花园、弥勒温泉康养，自然人文休闲一站齐。",
        pkg3_d1: "河口→屏边（大围山·滴水苗城）",
        pkg3_d2: "屏边→蒙自→建水（朝阳楼·朱家花园·紫陶街）",
        pkg3_d3: "建水→弥勒（温泉康养·城市观光）",
        pkg3_d4: "弥勒→蒙自（石榴园·诸子楼）→河口",

        // Package 4: Pricing
        pkg4_title: "儿童收费及费用说明",
        price_age: "年龄段",
        price_rate: "收费标准",
        age_above: "周岁以上",
        age_y: "岁",
        age_below: "岁以下",
        no_bed: "（不占床）",
        price_full: "全价成人",
        price_note1: "单房差：100元/晚",
        price_note2: "导游小费：20元/人/天",
        price_note3: "需办理中越边境旅游通行证",
        price_note4: "全程仅1个购物点（丝绸店）",

        // Common includes
        inc_hotel: "准四星酒店1晚",
        inc_hotel2: "准四星酒店2晚",
        inc_hotel3: "准四星酒店3晚",
        inc_hotel4: "准四星酒店4晚",
        inc_hotel6: "准四星酒店6晚",
        inc_guide: "越文导游全程服务",
        inc_ticket: "行程首道大门票",
        inc_meal: "2早4正餐",
        inc_meal4: "3早6正餐",
        inc_insurance: "旅游组合险+意外险",

        // Services
        services_title: "服务保障",
        services_subtitle: "红河边境旅游全程无忧服务",
        svc1_title: "边境通行证办理",
        svc1_desc: "协助办理中越边境旅游通行证，提前提交名单备案，口岸快速通关。",
        svc2_title: "越文导游全程服务",
        svc2_desc: "专业越南语导游全程陪同，沟通无障碍，贴心照顾每一位游客。",
        svc3_title: "准四星酒店住宿",
        svc3_desc: "全程入住准四星标准酒店，单房差仅100元/晚，舒适安心。",
        svc4_title: "空调大巴接送",
        svc4_desc: "全程旅游空调大巴，按人数调整车型，每人正座，河口口岸接送。",
        svc5_title: "双重旅游保险",
        svc5_desc: "云南旅游组合险+出境旅游意外险双重保障，安心出行。",
        svc6_title: "特色餐饮安排",
        svc6_desc: "蒙自过桥米线、建水烤豆腐、苗族特色餐，正餐全含。",

        // About
        about_title: "关于瓜豆旅游",
        about_desc1: "瓜豆旅游公司位于云南省红河州河口县，地处中越边境，是中国与越南之间的重要旅游门户。我们专注于为越南游客提供红河州边境旅游服务，线路覆盖屏边苗族风情、蒙自人文美食、建水千年古城、弥勒温泉康养。",
        about_desc2: "凭借8年以上的行业经验和专业的越文导游团队，我们已成功服务超过10,000名越南游客，所有线路均以河口口岸为起止点，配备越南语导游，办理中越边境旅游通行证，成为越中边境旅游的领军品牌。",
        about_f1: "正规旅行社资质",
        about_f2: "越南语导游团队",
        about_f3: "双重旅游保险",
        about_f4: "边境通行证办理",

        // Testimonials
        testimonials_title: "游客评价",
        testimonials_subtitle: "听听越南游客怎么说",
        test1_text: '"滴水苗城太美了！苗族文化非常有特色，导游越南语很好，全程沟通完全没问题。蒙自的石榴也很甜！"',
        test2_text: '"建水古城让我惊喜，朝阳楼和朱家花园太壮观了。过桥米线正宗又好吃，4天线路安排很合理！"',
        test3_text: '"弥勒温泉太舒服了！带着老人孩子走4天线路，导游很贴心，氧气和药品都有准备，服务很到位。"',
        test1_loc: "来自河内",
        test2_loc: "来自胡志明市",
        test3_loc: "来自海防",

        // Contact
        contact_title: "联系我们",
        contact_subtitle: "有任何问题？欢迎随时联系我们",
        contact_address_label: "地址",
        contact_address: "中国云南省红河州河口县",
        contact_phone_label: "电话",
        contact_email_label: "邮箱",
        name_placeholder: "您的姓名",
        phone_placeholder: "您的电话",
        email_placeholder: "您的邮箱",
        message_placeholder: "请输入您的留言...",
        subject_default: "请选择咨询主题",
        subject_package: "旅游线路咨询",
        subject_visa: "边境通行证办理",
        subject_custom: "定制行程",
        subject_other: "其他问题",
        submit: "提交咨询",

        // Footer
        footer_desc: "瓜豆旅游 — 您的专业越中边境旅游伙伴，河口口岸起止，越南语导游全程服务。让每一次旅行都成为难忘的回忆。",
        footer_links: "快速链接",
        footer_services: "热门服务",
        footer_contact: "联系方式",
        footer_rights: "版权所有",

        // Register/Login Modal
        register_title: "创建账户",
        register_subtitle: "加入瓜豆旅游，开启您的旅程",
        or: "或",
        phone_label: "手机号码",
        verification_code: "验证码",
        send_code: "发送验证码",
        full_name: "姓名",
        password: "密码",
        agree_terms: "我同意服务条款和隐私政策",
        register_btn: "注册",
        has_account: "已有账户？",
        login_here: "在此登录",
        login_title: "欢迎回来",
        login_subtitle: "登录您的瓜豆旅游账户",
        no_account: "没有账户？",
        register_here: "在此注册",

        // Misc
        code_sent: "验证码已发送",
        code_resend: "重新发送",
        register_success: "注册成功！",
        login_success: "登录成功！",
        consult_success: "咨询已提交，我们将尽快联系您！",
        consult_email: "详细咨询 HDgdtravel@outlook.com",
    },

    vi: {
        // Nav
        company_name: "Gua Dou Travel",
        nav_home: "Trang chủ",
        nav_packages: "Tuyến du lịch",
        nav_services: "Dịch vụ",
        nav_about: "Về chúng tôi",
        nav_contact: "Liên hệ",
        register: "Đăng ký",
        login: "Đăng nhập",

        // Hero
        hero_title: "Khám phá Hồng Hà, Gặp gỡ Vân Nam",
        hero_subtitle: "Gua Dou Travel — Khởi hành từ cửa khẩu Hà Khẩu, hướng dẫn viên tiếng Việt đồng hành, văn hóa Mèo - cổ thành - suối nước nóng",
        hero_cta: "Xem tuyến du lịch",
        hero_cta2: "Tư vấn miễn phí",

        // Stats
        stat_customers: "Khách hàng hài lòng",
        stat_routes: "Tuyến biên giới",
        stat_years: "Năm kinh nghiệm",
        stat_rating: "Đánh giá khách hàng",

        // Destinations
        dest_title: "Điểm đến du lịch Vân Nam",
        dest_subtitle: "Từ biên giới Hồng Hà đến núi tuyết tây bắc Vân Nam, toàn Vân Nam đợi bạn khám phá",
        dest_hekou: "Hà Khẩu",
        dest_hekou_desc: "Cửa ngõ Trung-Việt, điểm khởi hành",
        dest_pingbian: "Bình Biên",
        dest_pingbian_desc: "Văn hóa dân tộc Mèo, Thành Mèo",
        dest_mengzi: "Mông Tự",
        dest_mengzi_desc: "Mì qua cầu, vườn lựu vạn mẫu",
        dest_jianshui: "Kiến Thủy",
        dest_jianshui_desc: "Cổ thành ngàn năm, di tích Minh Thanh",
        dest_mile: "Di Lặc",
        dest_mile_desc: "Suối nước nóng, nghỉ dưỡng",
        dest_daweishan: "Đại Vi Sơn",
        dest_daweishan_desc: "Rừng nguyên sinh, kho gen động thực vật",
        dest_kunming: "Côn Minh",
        dest_kunming_desc: "Thành phố xuân, chim báo mẫu Điền Trì",
        dest_dali: "Đại Lý",
        dest_dali_desc: "Hoa tuyết gió trăng, Thương Sơn Nhĩ Hải",
        dest_lijang: "Lệ Giang",
        dest_lijang_desc: "Cổ thành Nạp Tây, Ngọc Long Tuyết Sơn",
        dest_shangrila: "Shangri-La",
        dest_shangrila_desc: "Tiên cảnh trần gian, quê hương tuyết Tạng",
        dest_banna: "Tây Song Bản Nạp",
        dest_banna_desc: "Rừng mưa nhiệt đới, văn hóa dân tộc Thái",
        dest_lugu: "Hồ Lô Cố",
        dest_lugu_desc: "Viên minh cao nguyên, mẫu hệ Moso",

        // Packages
        packages_title: "Tuyến du lịch Vân Nam",
        packages_subtitle: "Biên giới Hồng Hà · Đại Lệ Lệ Giang · Shangri-La · Tây Song Bản Nạp · Toàn tỉnh",
        days: "ngày",
        nights: "đêm",
        from: "từ",
        per_person: "người",
        book_now: "Đặt ngay",
        badge_short: "Ngắn",
        badge_hot: "Hot",
        badge_pricing: "Bảng giá",

        // Route filter tabs
        filter_all: "Tất cả tuyến",
        filter_border: "Biên giới Hồng Hà",
        filter_yunnan: "Toàn Vân Nam",
        filter_2d: "2 ngày",
        filter_3d: "3 ngày",
        filter_4d: "4 ngày",
        filter_5d: "5 ngày",
        filter_7d: "7 ngày",

        // Route region headers
        route_header_border: "Tuyến biên giới Hồng Hà",
        route_header_yunnan: "Tuyến toàn Vân Nam",

        // Destination categories
        dest_cat_border: "Biên giới Hồng Hà",
        dest_cat_northwest: "Phong cảnh tây bắc",
        dest_cat_tropical: "Nhiệt đới Bản Nạp",

        // Badge labels
        badge_classic: "Kinh điển",
        badge_compact: "Súc tích",
        badge_full: "Trọn gói",
        badge_scenic: "Phong cảnh",
        badge_popular: "Phổ biến",
        badge_tropical: "Nhiệt đới",
        badge_lake: "Hồ nước",
        badge_ultimate: "Tuyệt đỉnh",

        // Route 1: 河口+屏边+蒙自 2天1晚
        r1_title: "Hà Khẩu + Bình Biên + Mông Tự 2 ngày 1 đêm",
        r1_desc: "Văn hóa dân tộc Mèo + vườn lựu Mông Tự du lịch ngắn ngày. Thăm công viên đất ngập nước Thành Mèo Mục Dương Hà 4A, trung tâm hành chính châu Hồng Hà, vườn lựu vạn mẫu Tân An Sở, Thư Tử Lâu.",
        r1_d1: "Hà Khẩu → Bình Biên (90km/1.5h) Thành Mèo · đất ngập nước Mục Dương Hà",
        r1_d2: "Bình Biên → Mông Tự → Hà Khẩu Vườn lựu · Thư Tử Lâu · xuất cảnh",

        // Route 2: 河口+建水+蒙自 2天1晚
        r2_title: "Hà Khẩu + Kiến Thủy + Mông Tự 2 ngày 1 đêm",
        r2_desc: "Tuyến ngắn tinh hoa cổ thành Kiến Thủy. Triêu Dương Lâu, Vườn nhà họ Chu, phố gốm tím, vườn lựu Mông Tự, không bao gồm đoạn Bình Biên.",
        r2_d1: "Hà Khẩu → Kiến Thủy (Triêu Dương Lâu · Vườn họ Chu · Phố gốm tím)",
        r2_d2: "Kiến Thủy → Mông Tự (Vườn lựu · Thư Tử Lâu) → Hà Khẩu",

        // Route 3: 河口+屏边+建水+蒙自 2天1晚
        r3_title: "Hà Khẩu + Bình Biên + Kiến Thủy + Mông Tự 2 ngày 1 đêm",
        r3_desc: "Kết hợp súc tích Thành Mèo + cổ thành. Thành Mèo, Triêu Dương Lâu Kiến Thủy, Vườn họ Chu, vườn lựu Mông Tự, không bao gồm Đại Vi Sơn.",
        r3_d1: "Hà Khẩu → Bình Biên (Thành Mèo) → Kiến Thủy",
        r3_d2: "Kiến Thủy (Triêu Dương Lâu · Vườn họ Chu) → Mông Tự → Hà Khẩu",

        // Route 4: 河口+屏边+建水+蒙自 3天2晚
        r4_title: "Hà Khẩu + Bình Biên + Kiến Thủy + Mông Tự 3 ngày 2 đêm",
        r4_desc: "Bản Mèo + tinh hoa cổ thành Kiến Thủy. Rừng nguyên sinh Đại Vi Sơn, Thành Mèo, Triêu Dương Lâu Kiến Thủy, Vườn họ Chu, phố gốm tím, mì qua cầu Mông Tự.",
        r4_d1: "Hà Khẩu → Bình Biên (Rừng nguyên sinh Đại Vi Sơn · Thành Mèo)",
        r4_d2: "Bình Biên → Mông Tự → Kiến Thủy (Mì qua cầu · Triêu Dương Lâu · Vườn họ Chu)",
        r4_d3: "Kiến Thủy (Phố gốm tím · Đậu hũ nướng) → Mông Tự → Hà Khẩu",

        // Route 5: 河口+建水+弥勒+蒙自 3天2晚
        r5_title: "Hà Khẩu + Kiến Thủy + Di Lặc + Mông Tự 3 ngày 2 đêm",
        r5_desc: "Cổ thành + phiên bản nghỉ dưỡng suối nước nóng. Không qua Bình Biên, đi thẳng Triêu Dương Lâu Kiến Thủy, Vườn họ Chu, suối nước nóng nghỉ dưỡng Di Lặc, vườn lựu Mông Tự.",
        r5_d1: "Hà Khẩu → Kiến Thủy (Triêu Dương Lâu · Vườn họ Chu · Phố gốm tím)",
        r5_d2: "Kiến Thủy → Di Lặc (Suối nước nóng nghỉ dưỡng · Tham quan thành phố)",
        r5_d3: "Di Lặc → Mông Tự (Vườn lựu · Thư Tử Lâu) → Hà Khẩu",

        // Route 6: 4天3晚
        r6_title: "Hà Khẩu + Bình Biên + Mông Tự + Kiến Thủy + Di Lặc 4 ngày 3 đêm",
        r6_desc: "Tour sâu trọn gói! Bản Mèo + cổ thành + suối nước nóng toàn bộ. Rừng nguyên sinh Đại Vi Sơn, Thành Mèo, cổ thành Kiến Thủy, Vườn họ Chu, suối nước nóng nghỉ dưỡng Di Lặc, tự nhiên văn hóa nghỉ dưỡng một trạm đủ.",
        r6_d1: "Hà Khẩu → Bình Biên (Rừng nguyên sinh Đại Vi Sơn · Thành Mèo)",
        r6_d2: "Bình Biên → Mông Tự → Kiến Thủy (Mì qua cầu · Triêu Dương Lâu · Vườn họ Chu · Phố gốm tím)",
        r6_d3: "Kiến Thủy → Di Lặc (190km) Suối nước nóng nghỉ dưỡng · Tham quan thành phố",
        r6_d4: "Di Lặc → Mông Tự (Vườn lựu · Thư Tử Lâu) → Hà Khẩu xuất cảnh",

        // Route 7: 昆明+大理 3天2晚
        r7_title: "Côn Minh + Đại Lý 3 ngày 2 đêm",
        r7_desc: "Thành phố xuân Côn Minh + Đại Lý phong hoa tuyết nguyệt. Thăm Điền Trì, cổ thành Đại Lý, du thuyền Nhĩ Hải, chùa Tôn Thánh tam tháp, cổ trấn Song Lang.",
        r7_d1: "Côn Minh (Điền Trì · đập Hải Căng · Phường Kim Mã Bích Kê)",
        r7_d2: "Côn Minh → Đại Lý (Cổ thành Đại Lý · Chùa Tôn Thánh Tam Tháp · Du thuyền Nhĩ Hải)",
        r7_d3: "Đại Lý (Cổ trấn Song Lang · Đảo phong tình Nam Chiếu) → Côn Minh",

        // Route 8: 昆明+大理+丽江 4天3晚
        r8_title: "Côn Minh + Đại Lý + Lệ Giang 4 ngày 3 đêm",
        r8_desc: "Tuyến ba thành phố kinh điển Vân Nam. Điền Trì, cổ thành Đại Lý, Nhĩ Hải, cổ thành Lệ Giang, Ngọc Long Tuyết Sơn, Cổ Nguyệt Cốc, một lần thưởng thức tinh hoa Vân Nam.",
        r8_d1: "Côn Minh (Điền Trì · Phường Kim Mã Bích Kê)",
        r8_d2: "Côn Minh → Đại Lý (Cổ thành Đại Lý · Chùa Tôn Thánh Tam Tháp · Du thuyền Nhĩ Hải)",
        r8_d3: "Đại Lý → Lệ Giang (Cổ thành Lệ Giang · Phố Tứ Phương · Mộc Phủ)",
        r8_d4: "Lệ Giang (Ngọc Long Tuyết Sơn · Lam Nguyệt Cốc) → Côn Minh",

        // Route 9: 昆明+大理+丽江+香格里拉 5天4晚
        r9_title: "Côn Minh + Đại Lý + Lệ Giang + Shangri-La 5 ngày 4 đêm",
        r9_desc: "Tuyến vàng tây bắc Vân Nam! Thành xuân, phong hoa tuyết nguyệt, tuyết sơn cổ thành, tiên cảnh trần gian. Hổ Khiêu Hiệp, Phổ Đạt Thố, chùa Tông Tán Lâm một lần check-in.",
        r9_d1: "Côn Minh (Điền Trì · Phường Kim Mã Bích Kê)",
        r9_d2: "Côn Minh → Đại Lý (Cổ thành Đại Lý · Chùa Tôn Thánh Tam Tháp · Du thuyền Nhĩ Hải)",
        r9_d3: "Đại Lý → Lệ Giang (Cổ thành Lệ Giang · Phố Tứ Phương · Mộc Phủ)",
        r9_d4: "Lệ Giang → Hổ Khiêu Hiệp → Shangri-La (Cổ thành Độc Khách Tông · Chùa Tông Tán Lâm)",
        r9_d5: "Shangri-La (Vườn quốc gia Phổ Đạt Thố) → Lệ Giang → Côn Minh",

        // Route 10: 昆明+西双版纳 3天2晚
        r10_title: "Côn Minh + Tây Song Bản Nạp 3 ngày 2 đêm",
        r10_desc: "Rừng mưa nhiệt đới + văn hóa dân tộc Thái. Vườn thực vật nhiệt đới, Thung lũng Voi Rừng, chợ đêm Tinh Quang Cáo Trang, Vườn dân tộc Thái, công viên Man Thính.",
        r10_d1: "Côn Minh bay đến Bản Nạp → Vườn thực vật nhiệt đới → Chợ đêm Tinh Quang Cáo Trang",
        r10_d2: "Thung lũng Voi Rừng → Vườn dân tộc Thái · Tạt nước → Công viên Man Thính",
        r10_d3: "Bản Nạp (Chùa Phật lớn Mân Lặc) → Bay về Côn Minh",

        // Route 11: 昆明+大理+丽江+泸沽湖 5天4晚
        r11_title: "Côn Minh + Đại Lý + Lệ Giang + Hồ Lô Cố 5 ngày 4 đêm",
        r11_desc: "Tuyến hồ minh cao nguyên! Nhĩ Hải + Hồ Lô Cố song hồ. Cổ thành Đại Lý, cổ thành Lệ Giang, cầu Tẩu Hôn Moso, bán đảo Lý Cách, cảnh sắc non nước thu trọn.",
        r11_d1: "Côn Minh (Điền Trì · Phường Kim Mã Bích Kê)",
        r11_d2: "Côn Minh → Đại Lý (Cổ thành Đại Lý · Chùa Tôn Thánh Tam Tháp · Du thuyền Nhĩ Hải)",
        r11_d3: "Đại Lý → Lệ Giang (Cổ thành Lệ Giang · Phố Tứ Phương · Mộc Phủ)",
        r11_d4: "Lệ Giang → Hồ Lô Cố (Bán đảo Lý Cách · Cầu Tẩu Hôn · Lửa trại Moso)",
        r11_d5: "Hồ Lô Cố (Chèo thuyền · Đảo Lý Vụ Tỷ) → Lệ Giang → Côn Minh",

        // Route 12: 全云南7天6晚
        r12_title: "Vòng tròn tuyệt đỉnh toàn Vân Nam 7 ngày 6 đêm",
        r12_desc: "Một lần đi khấp Vân Nam! Côn Minh + Đại Lý + Lệ Giang + Shangri-La + Tây Song Bản Nạp, tuyết sơn, cổ thành, rừng mưa, hồ nước trải nghiệm đủ, chuyến Vân Nam không để lại tiếc nuối.",
        r12_d1: "Côn Minh (Điền Trì · Phường Kim Mã Bích Kê · Công viên Thúy Hồ)",
        r12_d2: "Côn Minh → Đại Lý (Cổ thành Đại Lý · Chùa Tôn Thánh Tam Tháp · Du thuyền Nhĩ Hải)",
        r12_d3: "Đại Lý → Lệ Giang (Cổ thành Lệ Giang · Phố Tứ Phương · Mộc Phủ)",
        r12_d4: "Lệ Giang → Hổ Khiêu Hiệp → Shangri-La (Chùa Tông Tán Lâm · Cổ thành Độc Khách Tông)",
        r12_d5: "Shangri-La (Phổ Đạt Thố) → Bay đến Tây Song Bản Nạp (Chợ đêm Tinh Quang)",
        r12_d6: "Bản Nạp (Thung lũng Voi Rừng · Vườn dân tộc Thái · Công viên Man Thính)",
        r12_d7: "Bản Nạp (Vườn thực vật nhiệt đới · Chùa Phật lớn Mân Lặc) → Bay về Côn Minh",

        // Landmark names
        landmarks_label: "Điểm nổi tiếng",
        lm_miaocity: "Thành Mèo",
        lm_muyang: "Đất ngập nước Mục Dương Hà",
        lm_pomegranate: "Vườn lựu vạn mẫu",
        lm_zhuzi: "Thư Tử Lâu",
        lm_chaoyang: "Triêu Dương Lâu",
        lm_zhugarden: "Vườn nhà họ Chu",
        lm_purplepottery: "Phố gốm tím",
        lm_jianshui: "Cổ thành Kiến Thủy",
        lm_daweishan: "Rừng nguyên sinh Đại Vi Sơn",
        lm_bridgenoodles: "Mì qua cầu Mông Tự",
        lm_milespring: "Suối nước nóng Di Lặc",
        lm_dianchi: "Hồ Điền Trì",
        lm_dalitown: "Cổ thành Đại Lý",
        lm_threepagodas: "Tam tháp chùa Tôn Thánh",
        lm_erhai: "Nhĩ Hải",
        lm_lijtown: "Cổ thành Lệ Giang",
        lm_jadedragon: "Ngọc Long Tuyết Sơn",
        lm_bluemoon: "Lam Nguyệt Cốc",
        lm_tigerleap: "Hổ Khiêu Hiệp",
        lm_songzanlin: "Chùa Tông Tán Lâm",
        lm_botanical: "Vườn thực vật nhiệt đới",
        lm_elephant: "Thung lũng Voi Rừng",
        lm_starlight: "Chợ đêm Tinh Quang",
        lm_manting: "Công viên Man Thính",
        lm_lugu: "Hồ Lô Cố",
        lm_marriage: "Cầu Tẩu Hôn",

        // Meal includes
        inc_1b2m: "1 sáng 2 chính",
        inc_2b4m: "2 sáng 4 chính",
        inc_3b6m: "3 sáng 6 chính",
        inc_4b8m: "4 sáng 8 chính",
        inc_6b12m: "6 sáng 12 chính",

        // Price detail
        single_room: "Phụ thu phòng đơn",
        tip_label: "Tiền tip",
        pricing_title: "Bảng giá trẻ em và chi phí",

        // Child pricing details
        inc_70: "Gồm chỗ xe · bữa chính · vé cửa đầu",
        inc_30: "Gồm chỗ xe · bữa chính · một phần vé ưu đãi",
        inc_10: "Chỉ gồm chỗ xe · vé tự trả tại chỗ",

        // Fee includes/excludes
        fee_incl_title: "Chi phí bao gồm",
        fee_incl1: "Xe cộ: Xe buýt điều hòa suốt hành trình, mỗi người một ghế riêng",
        fee_incl2: "Lưu trú: Phòng tiêu chuẩn khách sạn 4 sao, 2 người một phòng",
        fee_incl3: "Ẩm thực: Bữa sáng và chính theo lịch trình, không hoàn tiền nếu bỏ bữa",
        fee_incl4: "Vé tham quan: Vé cửa đầu, trẻ em trên 1.2m giá như người lớn",
        fee_incl5: "Hướng dẫn: Hướng dẫn viên tiếng Việt đồng hành suốt hành trình",
        fee_incl6: "Bảo hiểm: Bảo hiểm tổ hợp an toàn Vân Nam + bảo hiểm ngoài nước bất ngờ",
        fee_excl_title: "Chi phí không bao gồm",
        fee_excl1: "Chi tiêu cá nhân: Đồ uống, ăn vặt, giải trí tự chọn",
        fee_excl2: "Giấy chứng nhận sức khỏe: Giấy chứng nhận kiểm dịch y tế cửa khẩu xuất nhập cảnh",
        fee_excl3: "Vé Đại Vi Sơn và xe điện khu phong cảnh",
        fee_excl4: "Tiêu dùng tự nguyện tại cửa hàng lụa",
        fee_excl5: "Điểm tham quan mới ngoài lịch trình và trải nghiệm đặc sắc",

        // Terms section
        terms_title: "Lưu ý trước khi đi",
        terms_subtitle: "Vui lòng đọc kỹ trước khi đăng ký",
        term1_title: "Yêu cầu giấy tờ",
        term1_desc: "Cần làm giấy thông hành du lịch biên giới Trung-Việt trước, danh sách du khách nộp trước cho công ty du lịch lưu hồ sơ. Giấy người cao tuổi, giấy quân nhân, giấy sinh viên v.v. ngoài nước không hưởng giảm giá vé.",
        term2_title: "Quy định rời đoàn",
        term2_desc: "Suốt hành trình cấm tự ý rời đoàn, cần ký thỏa thuận liên quan. Tự ý rời đoàn không hoàn bất kỳ phí tour nào.",
        term3_title: "Quy định hoàn phí",
        term3_desc: "Tự nguyện bỏ bữa, bỏ lưu trú đều không hoàn phí. Bất khả kháng chưa phát sinh ăn ở vé theo thực tế hoàn lại, chi phí xe và lưu trú thêm du khách tự chịu.",
        term4_title: "Bất khả kháng",
        term4_desc: "Thiên tai, kiểm soát giao thông, thay đổi chính sách v.v., công ty du lịch có thể điều chỉnh lịch trình, các khoản chưa tiêu dùng hoàn tiền theo thực tế.",
        term5_title: "Quy định khiếu nại",
        term5_desc: "Chỉ lấy phiếu ý kiến tại chỗ của hướng dẫn viên làm bằng chứng hữu hiệu, khiếu nại sau khi về không có bằng chứng sẽ không được giải quyết.",
        term6_title: "Điều chỉnh lịch trình",
        term6_desc: "Trên tiền đề không giảm điểm tham quan, được sự đồng ý bằng văn bản của du khách có thể điều chỉnh thứ tự tham quan.",

        // Package 1
        pkg1_title: "Hà Khẩu + Bình Biên + Mông Tự 2 ngày 1 đêm",
        pkg1_desc: "Văn hóa Mèo + vườn lựu Mông Tự. Thăm công viên đất ngập nước Thành Mèo 4A, trung tâm hành chính châu Hồng Hà, vườn lựu vạn mẫu, Thư Tử Lâu.",
        pkg1_d1: "Hà Khẩu → Bình Biên (Thành Mèo ·湿地 Mục Dương Hà)",
        pkg1_d2: "Bình Biên → Mông Tự (Vườn lựu · Thư Tử Lâu) → Hà Khẩu",
        pkg1_inc1: "Đưa đón cửa khẩu Hà Khẩu",

        // Package 2
        pkg2_title: "Hà Khẩu + Bình Biên + Mông Tự + Kiến Thủy 3 ngày 2 đêm",
        pkg2_desc: "Bản Mèo + cổ thành Kiến Thủy tinh hoa. Rừng nguyên sinh Đại Vi Sơn, Thành Mèo, Triêu Dương Lâu, Vườn nhà họ Chu, phố gốm tím, mì qua cầu Mông Tự.",
        pkg2_d1: "Hà Khẩu → Bình Biên (Đại Vi Sơn · Thành Mèo)",
        pkg2_d2: "Bình Biên → Mông Tự → Kiến Thủy (Triêu Dương Lâu · Vườn họ Chu)",
        pkg2_d3: "Kiến Thủy → Mông Tự (Vườn lựu) → Hà Khẩu",

        // Package 3
        pkg3_title: "Hà Khẩu + Bình Biên + Mông Tự + Kiến Thủy + Di Lặc 4 ngày 3 đêm",
        pkg3_desc: "Tour sâu trọn gói! Bản Mèo + cổ thành + suối nước nóng. Rừng nguyên sinh Đại Vi Sơn, Thành Mèo, cổ thành Kiến Thủy, suối nước nóng Di Lặc.",
        pkg3_d1: "Hà Khẩu → Bình Biên (Đại Vi Sơn · Thành Mèo)",
        pkg3_d2: "Bình Biên → Mông Tự → Kiến Thủy (Triêu Dương Lâu · Vườn họ Chu · Phố gốm)",
        pkg3_d3: "Kiến Thủy → Di Lặc (Suối nước nóng · Tham quan thành phố)",
        pkg3_d4: "Di Lặc → Mông Tự (Vườn lựu · Thư Tử Lâu) → Hà Khẩu",

        // Package 4: Pricing
        pkg4_title: "Bảng giá trẻ em và chi phí",
        price_age: "Độ tuổi",
        price_rate: "Mức thu",
        age_above: "tuổi trở lên",
        age_y: " tuổi",
        age_below: " tuổi trở xuống",
        no_bed: "(không giường)",
        price_full: "Giá người lớn đầy đủ",
        price_note1: "Phụ thu phòng đơn: 100 NDT/đêm",
        price_note2: "Tiền tip hướng dẫn: 20 NDT/người/ngày",
        price_note3: "Cần làm giấy thông hành du lịch biên giới Trung-Việt",
        price_note4: "Chỉ 1 điểm mua sắm (cửa hàng lụa)",

        // Common includes
        inc_hotel: "Khách sạn 4 sao 1 đêm",
        inc_hotel2: "Khách sạn 4 sao 2 đêm",
        inc_hotel3: "Khách sạn 4 sao 3 đêm",
        inc_hotel4: "Khách sạn 4 sao 4 đêm",
        inc_hotel6: "Khách sạn 4 sao 6 đêm",
        inc_guide: "Hướng dẫn viên tiếng Việt suốt hành trình",
        inc_ticket: "Vé tham quan cửa đầu",
        inc_meal: "2 sáng 4 chính",
        inc_meal4: "3 sáng 6 chính",
        inc_insurance: "Bảo hiểm du lịch tổ hợp + Bảo hiểm ngoài nước",

        // Services
        services_title: "Dịch vụ đảm bảo",
        services_subtitle: "Dịch vụ trọn gói du lịch biên giới Hồng Hà",
        svc1_title: "Làm giấy thông hành",
        svc1_desc: "Hỗ trợ làm giấy thông hành du lịch biên giới Trung-Việt, nộp danh sách trước, qua cửa khẩu nhanh chóng.",
        svc2_title: "Hướng dẫn viên tiếng Việt",
        svc2_desc: "Hướng dẫn viên tiếng Việt chuyên nghiệp đồng hành suốt hành trình, không rào cản ngôn ngữ.",
        svc3_title: "Khách sạn 4 sao",
        svc3_desc: "Lưu trú khách sạn tiêu chuẩn 4 sao, phụ thu phòng đơn chỉ 100 NDT/đêm.",
        svc4_title: "Xe buýt điều hòa đưa đón",
        svc4_desc: "Xe buýt du lịch điều hòa suốt hành trình, điều chỉnh xe theo số người, mỗi người một ghế.",
        svc5_title: "Bảo hiểm du lịch kép",
        svc5_desc: "Bảo hiểm du lịch tổ hợp Vân Nam + Bảo hiểm ngoài nước, an tâm hành trình.",
        svc6_title: "Ẩm thực đặc sắc",
        svc6_desc: "Mì qua cầu Mông Tự, đậu hũ nướng Kiến Thủy, món Mèo đặc sản, bữa chính đầy đủ.",

        // About
        about_title: "Về Gua Dou Travel",
        about_desc1: "Công ty Du lịch Gua Dou tọa lạc tại huyện Hà Khẩu, châu Hồng Hà, tỉnh Vân Nam, nằm ở vùng biên giới Trung-Việt. Chúng tôi chuyên cung cấp dịch vụ du lịch biên giới châu Hồng Hà cho du khách Việt Nam, tuyến đường bao gồm Bình Biên văn hóa Mèo, Mông Tự ẩm thực, Kiến Thủy cổ thành, Di Lặc suối nước nóng.",
        about_desc2: "Với hơn 8 năm kinh nghiệm và đội ngũ hướng dẫn viên tiếng Việt chuyên nghiệp, chúng tôi đã phục vụ thành công hơn 10.000 du khách Việt Nam. Mọi tuyến đều khởi hành từ cửa khẩu Hà Khẩu,配备 hướng dẫn viên tiếng Việt, làm giấy thông hành biên giới Trung-Việt.",
        about_f1: "Công ty du lịch chính quy",
        about_f2: "Đội ngũ hướng dẫn viên tiếng Việt",
        about_f3: "Bảo hiểm du lịch kép",
        about_f4: "Làm giấy thông hành biên giới",

        // Testimonials
        testimonials_title: "Đánh giá du khách",
        testimonials_subtitle: "Nghe du khách Việt Nam nói gì",
        test1_text: '"Thành Mèo quá đẹp! Văn hóa dân tộc Mèo rất đặc sắc, hướng dẫn viên nói tiếng Việt rất tốt, giao tiếp cả hành trình không vấn đề. Lựu Mông Tự cũng rất ngọt!"',
        test2_text: '"Cổ thành Kiến Thủy làm tôi bất ngờ, Triêu Dương Lâu và Vườn họ Chu quá tráng lệ. Mì qua cầu chính gốc ngon极了, lịch trình 4 ngày rất hợp lý!"',
        test3_text: '"Suối nước nóng Di Lặc quá thoải mái! Đưa gia đình đi tuyến 4 ngày, hướng dẫn viên rất chu đáo, thuốc men cũng chuẩn bị sẵn, dịch vụ rất tốt."',
        test1_loc: "Từ Hà Nội",
        test2_loc: "Từ TP.HCM",
        test3_loc: "Từ Hải Phòng",

        // Contact
        contact_title: "Liên hệ chúng tôi",
        contact_subtitle: "Có bất kỳ câu hỏi? Liên hệ chúng tôi bất cứ lúc nào",
        contact_address_label: "Địa chỉ",
        contact_address: "Huyện Hà Khẩu, Châu Hồng Hà, Tỉnh Vân Nam, Trung Quốc",
        contact_phone_label: "Điện thoại",
        contact_email_label: "Email",
        name_placeholder: "Tên của bạn",
        phone_placeholder: "Số điện thoại",
        email_placeholder: "Email của bạn",
        message_placeholder: "Nhập tin nhắn của bạn...",
        subject_default: "Chọn chủ đề tư vấn",
        subject_package: "Tư vấn tuyến du lịch",
        subject_visa: "Làm giấy thông hành",
        subject_custom: "Lịch trình riêng",
        subject_other: "Vấn đề khác",
        submit: "Gửi tư vấn",

        // Footer
        footer_desc: "Gua Dou Travel — Đối tác du lịch biên giới Việt-Trung chuyên nghiệp, khởi hành từ cửa khẩu Hà Khẩu, hướng dẫn viên tiếng Việt đồng hành.",
        footer_links: "Liên kết nhanh",
        footer_services: "Dịch vụ phổ biến",
        footer_contact: "Thông tin liên hệ",
        footer_rights: "Bản quyền đã bảo hộ",

        // Register/Login Modal
        register_title: "Tạo tài khoản",
        register_subtitle: "Tham gia Gua Dou Travel, bắt đầu hành trình của bạn",
        or: "hoặc",
        phone_label: "Số điện thoại",
        verification_code: "Mã xác nhận",
        send_code: "Gửi mã",
        full_name: "Họ và tên",
        password: "Mật khẩu",
        agree_terms: "Tôi đồng ý với Điều khoản dịch vụ và Chính sách bảo mật",
        register_btn: "Đăng ký",
        has_account: "Đã có tài khoản?",
        login_here: "Đăng nhập tại đây",
        login_title: "Chào mừng trở lại",
        login_subtitle: "Đăng nhập vào tài khoản Gua Dou Travel",
        no_account: "Chưa có tài khoản?",
        register_here: "Đăng ký tại đây",

        // Misc
        code_sent: "Mã xác nhận đã được gửi",
        code_resend: "Gửi lại",
        register_success: "Đăng ký thành công!",
        login_success: "Đăng nhập thành công!",
        consult_success: "Tư vấn đã được gửi, chúng tôi sẽ liên hệ bạn sớm nhất!",
        consult_email: "Liên hệ chi tiết HDgdtravel@outlook.com",
    },

    en: {
        // Nav
        company_name: "Gua Dou Travel",
        nav_home: "Home",
        nav_packages: "Tour Routes",
        nav_services: "Services",
        nav_about: "About Us",
        nav_contact: "Contact",
        register: "Register",
        login: "Login",

        // Hero
        hero_title: "Explore Honghe, Discover Yunnan",
        hero_subtitle: "Gua Dou Travel — Departing from Hekou Port, Vietnamese-speaking guides, Miao culture - ancient town - hot springs all in one",
        hero_cta: "Browse Tour Routes",
        hero_cta2: "Free Consultation",

        // Stats
        stat_customers: "Happy Customers",
        stat_routes: "Border Routes",
        stat_years: "Years of Experience",
        stat_rating: "Customer Rating",

        // Destinations
        dest_title: "Yunnan Travel Destinations",
        dest_subtitle: "From Honghe Border to Northwest Snow Mountains, all of Yunnan awaits",
        dest_hekou: "Hekou",
        dest_hekou_desc: "China-Vietnam gateway, departure point",
        dest_pingbian: "Pingbian",
        dest_pingbian_desc: "Miao ethnic culture, Dishui Miao City",
        dest_mengzi: "Mengzi",
        dest_mengzi_desc: "Crossing-bridge noodles, pomegranate orchards",
        dest_jianshui: "Jianshui",
        dest_jianshui_desc: "Millennium ancient town, Ming-Qing heritage",
        dest_mile: "Mile",
        dest_mile_desc: "Hot springs, wellness resort",
        dest_daweishan: "Daweishan",
        dest_daweishan_desc: "Primeval forest, gene bank of flora & fauna",
        dest_kunming: "Kunming",
        dest_kunming_desc: "Spring City, Dianchi Seagulls",
        dest_dali: "Dali",
        dest_dali_desc: "Wind Flower Snow Moon, Cangshan Erhai",
        dest_lijang: "Lijiang",
        dest_lijang_desc: "Naxi Ancient Town, Jade Dragon Snow Mountain",
        dest_shangrila: "Shangri-La",
        dest_shangrila_desc: "Paradise on Earth, Tibetan Snowland",
        dest_banna: "Xishuangbanna",
        dest_banna_desc: "Tropical Rainforest, Dai Culture",
        dest_lugu: "Lugu Lake",
        dest_lugu_desc: "Plateau Pearl, Mosuo Matriarchy",

        // Packages
        packages_title: "Yunnan Tour Routes",
        packages_subtitle: "Honghe Border · Dali Lijiang · Shangri-La · Xishuangbanna · All Yunnan",
        days: "Days",
        nights: "Nights",
        from: "from",
        per_person: "person",
        book_now: "Book Now",
        badge_short: "Short",
        badge_hot: "Hot",
        badge_pricing: "Pricing",

        // Route filter tabs
        filter_all: "All Routes",
        filter_border: "Honghe Border",
        filter_yunnan: "All Yunnan",
        filter_2d: "2 Days",
        filter_3d: "3 Days",
        filter_4d: "4 Days",
        filter_5d: "5 Days",
        filter_7d: "7 Days",

        // Route region headers
        route_header_border: "Honghe Border Routes",
        route_header_yunnan: "All Yunnan Routes",

        // Destination categories
        dest_cat_border: "Honghe Border",
        dest_cat_northwest: "Northwest Yunnan",
        dest_cat_tropical: "Tropical Banna",

        // Badge labels
        badge_classic: "Classic",
        badge_compact: "Compact",
        badge_full: "Full Route",
        badge_scenic: "Scenic",
        badge_popular: "Popular",
        badge_tropical: "Tropical",
        badge_lake: "Lakes",
        badge_ultimate: "Ultimate",

        // Route 1: 河口+屏边+蒙自 2天1晚
        r1_title: "Hekou + Pingbian + Mengzi 2-Day Tour",
        r1_desc: "Miao culture + Mengzi pomegranate short trip. Visit 4A Dishui Miao City Wetland Park, Honghe Administrative Center, Xin'ansuo Pomegranate Orchards, Zhuzi Tower.",
        r1_d1: "Hekou → Pingbian (90km/1.5h) Dishui Miao City · Muyang River Wetland",
        r1_d2: "Pingbian → Mengzi → Hekou Pomegranate Orchard · Zhuzi Tower · Border Exit",

        // Route 2: 河口+建水+蒙自 2天1晚
        r2_title: "Hekou + Jianshui + Mengzi 2-Day Tour",
        r2_desc: "Jianshui ancient town essence short route. Chaoyang Tower, Zhu Family Garden, Purple Pottery Street, Mengzi pomegranate orchards; excludes Pingbian section.",
        r2_d1: "Hekou → Jianshui (Chaoyang Tower · Zhu Family Garden · Purple Pottery Street)",
        r2_d2: "Jianshui → Mengzi (Pomegranate Orchard · Zhuzi Tower) → Hekou",

        // Route 3: 河口+屏边+建水+蒙自 2天1晚
        r3_title: "Hekou + Pingbian + Jianshui + Mengzi 2-Day Tour",
        r3_desc: "Miao City + ancient town compact combo. Dishui Miao City, Jianshui Chaoyang Tower, Zhu Family Garden, Mengzi pomegranate orchards; excludes Daweishan.",
        r3_d1: "Hekou → Pingbian (Dishui Miao City) → Jianshui",
        r3_d2: "Jianshui (Chaoyang Tower · Zhu Family Garden) → Mengzi → Hekou",

        // Route 4: 河口+屏边+建水+蒙自 3天2晚
        r4_title: "Hekou + Pingbian + Jianshui + Mengzi 3-Day Tour",
        r4_desc: "Miao village + Jianshui ancient town essence. Daweishan primeval forest, Dishui Miao City, Jianshui Chaoyang Tower, Zhu Family Garden, Purple Pottery Street, Mengzi crossing-bridge noodles.",
        r4_d1: "Hekou → Pingbian (Daweishan Primeval Forest · Dishui Miao City)",
        r4_d2: "Pingbian → Mengzi → Jianshui (Crossing-bridge Noodles · Chaoyang Tower · Zhu Family Garden)",
        r4_d3: "Jianshui (Purple Pottery Street · Roasted Tofu) → Mengzi → Hekou",

        // Route 5: 河口+建水+弥勒+蒙自 3天2晚
        r5_title: "Hekou + Jianshui + Mile + Mengzi 3-Day Tour",
        r5_desc: "Ancient town + hot springs leisure edition. Excludes Pingbian, direct to Jianshui Chaoyang Tower, Zhu Family Garden, Mile hot springs wellness, Mengzi pomegranate orchards.",
        r5_d1: "Hekou → Jianshui (Chaoyang Tower · Zhu Family Garden · Purple Pottery Street)",
        r5_d2: "Jianshui → Mile (Hot Springs Wellness · City Tour)",
        r5_d3: "Mile → Mengzi (Pomegranate Orchard · Zhuzi Tower) → Hekou",

        // Route 6: 4天3晚
        r6_title: "Hekou + Pingbian + Mengzi + Jianshui + Mile 4-Day Tour",
        r6_desc: "Full-depth tour! Miao village + ancient town + hot springs all covered. Daweishan primeval forest, Dishui Miao City, Jianshui ancient town, Zhu Family Garden, Mile hot springs wellness — nature, culture, leisure all in one.",
        r6_d1: "Hekou → Pingbian (Daweishan Primeval Forest · Dishui Miao City)",
        r6_d2: "Pingbian → Mengzi → Jianshui (Crossing-bridge Noodles · Chaoyang Tower · Zhu Family Garden · Purple Pottery Street)",
        r6_d3: "Jianshui → Mile (190km) Hot Springs Wellness · City Tour",
        r6_d4: "Mile → Mengzi (Pomegranate Orchard · Zhuzi Tower) → Hekou Border Exit",

        // Route 7: Kunming + Dali 3-Day Tour
        r7_title: "Kunming + Dali 3-Day Tour",
        r7_desc: "Spring City Kunming + Romantic Dali. Visit Dianchi Lake, Dali Ancient Town, Erhai Cruise, Three Pagodas, Shuanglang Town.",
        r7_d1: "Kunming (Dianchi Lake · Haigeng Dam · Jinma Biji Arch)",
        r7_d2: "Kunming → Dali (Dali Ancient Town · Three Pagodas · Erhai Cruise)",
        r7_d3: "Dali (Shuanglang Town · Nanzhao Island) → Kunming",

        // Route 8: Kunming + Dali + Lijiang 4-Day Tour
        r8_title: "Kunming + Dali + Lijiang 4-Day Tour",
        r8_desc: "Classic 3-city route. Dianchi Lake, Dali Ancient Town, Erhai, Lijiang Ancient Town, Jade Dragon Snow Mountain, Blue Moon Valley — Yunnan's best in one trip.",
        r8_d1: "Kunming (Dianchi Lake · Jinma Biji Arch)",
        r8_d2: "Kunming → Dali (Dali Ancient Town · Three Pagodas · Erhai Cruise)",
        r8_d3: "Dali → Lijiang (Lijiang Ancient Town · Sifang Street · Mu Palace)",
        r8_d4: "Lijiang (Jade Dragon Snow Mountain · Blue Moon Valley) → Kunming",

        // Route 9: Kunming + Dali + Lijiang + Shangri-La 5-Day Tour
        r9_title: "Kunming + Dali + Lijiang + Shangri-La 5-Day Tour",
        r9_desc: "Northwest Yunnan golden route! Spring City, romantic scenery, snow mountains & ancient towns, paradise on Earth. Tiger Leaping Gorge, Pudacuo, Songzanlin Monastery all in one.",
        r9_d1: "Kunming (Dianchi Lake · Jinma Biji Arch)",
        r9_d2: "Kunming → Dali (Dali Ancient Town · Three Pagodas · Erhai Cruise)",
        r9_d3: "Dali → Lijiang (Lijiang Ancient Town · Sifang Street · Mu Palace)",
        r9_d4: "Lijiang → Tiger Leaping Gorge → Shangri-La (Dukezong Ancient Town · Songzanlin Monastery)",
        r9_d5: "Shangri-La (Pudacuo National Park) → Lijiang → Kunming",

        // Route 10: Kunming + Xishuangbanna 3-Day Tour
        r10_title: "Kunming + Xishuangbanna 3-Day Tour",
        r10_desc: "Tropical rainforest + Dai culture tour. Tropical Botanical Garden, Wild Elephant Valley, Starlight Night Market, Dai Park, Manting Park.",
        r10_d1: "Fly Kunming to Banna → Tropical Botanical Garden → Starlight Night Market",
        r10_d2: "Wild Elephant Valley → Dai Park · Water Splashing → Manting Park",
        r10_d3: "Banna (Mengle Grand Buddha Temple) → Fly to Kunming",

        // Route 11: Kunming + Dali + Lijiang + Lugu Lake 5-Day Tour
        r11_title: "Kunming + Dali + Lijiang + Lugu Lake 5-Day Tour",
        r11_desc: "Plateau pearl route! Erhai + Lugu Lake dual-lake tour. Dali Ancient Town, Lijiang Ancient Town, Mosuo Marriage Bridge, Lige Peninsula — stunning lake & mountain views.",
        r11_d1: "Kunming (Dianchi Lake · Jinma Biji Arch)",
        r11_d2: "Kunming → Dali (Dali Ancient Town · Three Pagodas · Erhai Cruise)",
        r11_d3: "Dali → Lijiang (Lijiang Ancient Town · Sifang Street · Mu Palace)",
        r11_d4: "Lijiang → Lugu Lake (Lige Peninsula · Marriage Bridge · Moso Bonfire)",
        r11_d5: "Lugu Lake (Boat Ride · Liwubi Island) → Lijiang → Kunming",

        // Route 12: Ultimate Yunnan Grand Tour 7-Day
        r12_title: "Ultimate Yunnan Grand Tour 7-Day",
        r12_desc: "See all of Yunnan in one trip! Kunming + Dali + Lijiang + Shangri-La + Xishuangbanna — snow mountains, ancient towns, rainforests, lakes — the complete Yunnan experience.",
        r12_d1: "Kunming (Dianchi Lake · Jinma Biji Arch · Cuihu Park)",
        r12_d2: "Kunming → Dali (Dali Ancient Town · Three Pagodas · Erhai Cruise)",
        r12_d3: "Dali → Lijiang (Lijiang Ancient Town · Sifang Street · Mu Palace)",
        r12_d4: "Lijiang → Tiger Leaping Gorge → Shangri-La (Songzanlin Monastery · Dukezong Ancient Town)",
        r12_d5: "Shangri-La (Pudacuo) → Fly to Xishuangbanna (Starlight Night Market)",
        r12_d6: "Banna (Wild Elephant Valley · Dai Park · Manting Park)",
        r12_d7: "Banna (Tropical Botanical Garden · Mengle Grand Temple) → Fly to Kunming",

        // Landmark names
        landmarks_label: "Famous Landmarks",
        lm_miaocity: "Dishui Miao City",
        lm_muyang: "Muyang River Wetland",
        lm_pomegranate: "Pomegranate Orchards",
        lm_zhuzi: "Zhuzi Tower",
        lm_chaoyang: "Chaoyang Tower",
        lm_zhugarden: "Zhu Family Garden",
        lm_purplepottery: "Purple Pottery Street",
        lm_jianshui: "Jianshui Ancient Town",
        lm_daweishan: "Daweishan Primeval Forest",
        lm_bridgenoodles: "Crossing-bridge Noodles",
        lm_milespring: "Mile Hot Springs",
        lm_dianchi: "Dianchi Lake",
        lm_dalitown: "Dali Ancient Town",
        lm_threepagodas: "Three Pagodas",
        lm_erhai: "Erhai Lake",
        lm_lijtown: "Lijiang Ancient Town",
        lm_jadedragon: "Jade Dragon Snow Mountain",
        lm_bluemoon: "Blue Moon Valley",
        lm_tigerleap: "Tiger Leaping Gorge",
        lm_songzanlin: "Songzanlin Monastery",
        lm_botanical: "Tropical Botanical Garden",
        lm_elephant: "Wild Elephant Valley",
        lm_starlight: "Starlight Night Market",
        lm_manting: "Manting Park",
        lm_lugu: "Lugu Lake",
        lm_marriage: "Marriage Bridge",

        // Meal includes
        inc_1b2m: "1 breakfast, 2 main meals",
        inc_2b4m: "2 breakfasts, 4 main meals",
        inc_3b6m: "3 breakfasts, 6 main meals",
        inc_4b8m: "4 breakfasts, 8 main meals",
        inc_6b12m: "6 breakfasts, 12 main meals",

        // Price detail
        single_room: "Single room",
        tip_label: "Tip",
        pricing_title: "Child Pricing & Fee Details",

        // Child pricing details
        inc_70: "Seat, meals, first-entry ticket",
        inc_30: "Seat, meals, some discount tickets",
        inc_10: "Seat only, tickets on-site",

        // Fee includes/excludes
        fee_incl_title: "Fee Includes",
        fee_incl1: "Transport: Air-conditioned bus throughout, individual seat for each person",
        fee_incl2: "Accommodation: 4-star standard hotel room, 2 persons per room",
        fee_incl3: "Meals: Breakfast and main meals as indicated in itinerary, no refund for skipped meals",
        fee_incl4: "Tickets: First-entry attraction tickets, children over 1.2m same as adult",
        fee_incl5: "Guide: Vietnamese-speaking guide service throughout",
        fee_incl6: "Insurance: Yunnan safety combo insurance + outbound accident insurance",
        fee_excl_title: "Fee Excludes",
        fee_excl1: "Personal expenses: Beverages, snacks, optional entertainment",
        fee_excl2: "Health certificate: Port entry-exit inspection and quarantine health certificate",
        fee_excl3: "Daweishan tickets and scenic area electric cart",
        fee_excl4: "Silk shop voluntary shopping expenses",
        fee_excl5: "Additional attractions and special experiences outside the itinerary",

        // Terms section
        terms_title: "Travel Notice",
        terms_subtitle: "Please read carefully before booking",
        term1_title: "ID Requirements",
        term1_desc: "China-Vietnam border travel pass must be obtained in advance; tourist roster must be submitted to the travel agency for record in advance. Senior cards, military IDs, student cards, etc. are not eligible for ticket discounts outside China.",
        term2_title: "Leaving Group Rules",
        term2_desc: "Leaving the group without authorization is strictly prohibited throughout the trip; a related agreement must be signed. No tour fee refund for unauthorized departure.",
        term3_title: "Refund Rules",
        term3_desc: "Voluntarily skipping meals or accommodation is non-refundable. Force majeure: unused meals, accommodation, and tickets refunded based on actual costs; additional transport and accommodation expenses borne by tourists.",
        term4_title: "Force Majeure",
        term4_desc: "Natural disasters, traffic control, policy changes, etc. — the travel agency may adjust the itinerary; unused items refunded based on actual costs.",
        term5_title: "Complaint Rules",
        term5_desc: "Only the on-site feedback form signed with the guide is valid; complaints after return without supporting evidence will not be accepted.",
        term6_title: "Itinerary Adjustment",
        term6_desc: "Without reducing attractions, the visiting order may be adjusted with written consent from tourists.",

        // Package 1
        pkg1_title: "Hekou + Pingbian + Mengzi 2-Day Tour",
        pkg1_desc: "Miao culture + Mengzi pomegranate short trip. Visit 4A Dishui Miao City Wetland Park, Honghe Administrative Center, Xin'ansuo Pomegranate Orchards, Zhuzi Tower.",
        pkg1_d1: "Hekou → Pingbian (Dishui Miao City · Muyang River Wetland)",
        pkg1_d2: "Pingbian → Mengzi (Pomegranate Orchard · Zhuzi Tower) → Hekou",
        pkg1_inc1: "Hekou Port pickup & drop-off",

        // Package 2
        pkg2_title: "Hekou + Pingbian + Mengzi + Jianshui 3-Day Tour",
        pkg2_desc: "Miao village + Jianshui ancient town essence. Daweishan primeval forest, Dishui Miao City, Chaoyang Tower, Zhu Family Garden, Purple Pottery Street, Mengzi crossing-bridge noodles.",
        pkg2_d1: "Hekou → Pingbian (Daweishan · Dishui Miao City)",
        pkg2_d2: "Pingbian → Mengzi → Jianshui (Chaoyang Tower · Zhu Family Garden)",
        pkg2_d3: "Jianshui → Mengzi (Pomegranate Orchard) → Hekou",

        // Package 3
        pkg3_title: "Hekou + Pingbian + Mengzi + Jianshui + Mile 4-Day Tour",
        pkg3_desc: "Full-depth tour! Miao village + ancient town + hot springs. Daweishan forest, Dishui Miao City, Jianshui ancient town, Zhu Family Garden, Mile hot springs wellness.",
        pkg3_d1: "Hekou → Pingbian (Daweishan · Dishui Miao City)",
        pkg3_d2: "Pingbian → Mengzi → Jianshui (Chaoyang Tower · Zhu Garden · Pottery Street)",
        pkg3_d3: "Jianshui → Mile (Hot springs wellness · City tour)",
        pkg3_d4: "Mile → Mengzi (Pomegranate Orchard · Zhuzi Tower) → Hekou",

        // Package 4: Pricing
        pkg4_title: "Child Pricing & Fee Details",
        price_age: "Age Group",
        price_rate: "Rate",
        age_above: " years old & above",
        age_y: " years old",
        age_below: " years old & under",
        no_bed: "(no bed)",
        price_full: "Full adult price",
        price_note1: "Single room supplement: ¥100/night",
        price_note2: "Guide tip: ¥20/person/day",
        price_note3: "China-Vietnam border travel pass required",
        price_note4: "Only 1 shopping stop (silk shop)",

        // Common includes
        inc_hotel: "4-star hotel 1 night",
        inc_hotel2: "4-star hotel 2 nights",
        inc_hotel3: "4-star hotel 3 nights",
        inc_hotel4: "4-star hotel 4 nights",
        inc_hotel6: "4-star hotel 6 nights",
        inc_guide: "Vietnamese-speaking guide throughout",
        inc_ticket: "First-entry attraction tickets",
        inc_meal: "2 breakfasts, 4 main meals",
        inc_meal4: "3 breakfasts, 6 main meals",
        inc_insurance: "Tour combo insurance + outbound accident insurance",

        // Services
        services_title: "Service Guarantees",
        services_subtitle: "Worry-free border tourism services",
        svc1_title: "Border Pass Assistance",
        svc1_desc: "Assist with China-Vietnam border travel pass, submit roster in advance, fast border crossing.",
        svc2_title: "Vietnamese-Speaking Guide",
        svc2_desc: "Professional Vietnamese-speaking guide throughout, no language barriers.",
        svc3_title: "4-Star Hotel Accommodation",
        svc3_desc: "Stay at 4-star standard hotels, single room supplement only ¥100/night.",
        svc4_title: "Air-Conditioned Bus",
        svc4_desc: "Tour bus with A/C throughout, vehicle adjusted by group size, each person a seat.",
        svc5_title: "Dual Travel Insurance",
        svc5_desc: "Yunnan tour combo insurance + outbound travel accident insurance, travel with peace of mind.",
        svc6_title: "Specialty Dining",
        svc6_desc: "Mengzi crossing-bridge noodles, Jianshui roasted tofu, Miao cuisine, all main meals included.",

        // About
        about_title: "About Gua Dou Travel",
        about_desc1: "Gua Dou Travel Company is located in Hekou County, Honghe Prefecture, Yunnan Province, at the China-Vietnam border. We specialize in providing Honghe border tourism for Vietnamese visitors, covering Pingbian Miao culture, Mengzi food heritage, Jianshui ancient town, and Mile hot springs wellness.",
        about_desc2: "With over 8 years of experience and professional Vietnamese-speaking guides, we have served over 10,000 Vietnamese tourists. All routes depart from Hekou Port with Vietnamese-speaking guides and China-Vietnam border travel pass assistance.",
        about_f1: "Licensed travel agency",
        about_f2: "Vietnamese-speaking guide team",
        about_f3: "Dual travel insurance",
        about_f4: "Border pass assistance",

        // Testimonials
        testimonials_title: "Tourist Reviews",
        testimonials_subtitle: "What Vietnamese tourists say about us",
        test1_text: '"Dishui Miao City is so beautiful! Miao culture is very unique, the guide speaks great Vietnamese, no communication issues at all. Mengzi pomegranates are so sweet!"',
        test2_text: '"Jianshui ancient town surprised me — Chaoyang Tower and Zhu Family Garden are magnificent. The crossing-bridge noodles are authentic and delicious. 4-day itinerary is well-planned!"',
        test3_text: '"Mile hot springs are so relaxing! Took the 4-day route with family, the guide was very attentive, medicine and supplies prepared. Great service!"',
        test1_loc: "From Hanoi",
        test2_loc: "From Ho Chi Minh City",
        test3_loc: "From Hai Phong",

        // Contact
        contact_title: "Contact Us",
        contact_subtitle: "Have questions? Feel free to contact us anytime",
        contact_address_label: "Address",
        contact_address: "Hekou County, Honghe Prefecture, Yunnan Province, China",
        contact_phone_label: "Phone",
        contact_email_label: "Email",
        name_placeholder: "Your name",
        phone_placeholder: "Your phone number",
        email_placeholder: "Your email",
        message_placeholder: "Enter your message...",
        subject_default: "Select a topic",
        subject_package: "Tour route inquiry",
        subject_visa: "Border pass assistance",
        subject_custom: "Custom itinerary",
        subject_other: "Other questions",
        submit: "Submit Inquiry",

        // Footer
        footer_desc: "Gua Dou Travel — Your professional China-Vietnam border travel partner, departing from Hekou Port, Vietnamese-speaking guides throughout.",
        footer_links: "Quick Links",
        footer_services: "Popular Services",
        footer_contact: "Contact Info",
        footer_rights: "All Rights Reserved",

        // Register/Login Modal
        register_title: "Create Account",
        register_subtitle: "Join Gua Dou Travel, start your journey",
        or: "or",
        phone_label: "Phone Number",
        verification_code: "Verification Code",
        send_code: "Send Code",
        full_name: "Full Name",
        password: "Password",
        agree_terms: "I agree to the Terms of Service and Privacy Policy",
        register_btn: "Register",
        has_account: "Already have an account?",
        login_here: "Login here",
        login_title: "Welcome Back",
        login_subtitle: "Login to your Gua Dou Travel account",
        no_account: "Don't have an account?",
        register_here: "Register here",

        // Misc
        code_sent: "Code sent",
        code_resend: "Resend",
        register_success: "Registration successful!",
        login_success: "Login successful!",
        consult_success: "Inquiry submitted, we will contact you soon!",
        consult_email: "Contact for details HDgdtravel@outlook.com",
    }
};
